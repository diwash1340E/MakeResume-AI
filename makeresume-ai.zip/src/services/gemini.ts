import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface TailoredPackage {
  tailored_resume?: string;
  keyword_match_score: number;
  cover_letter?: string;
  lor_request_email?: string;
  analysis_breakdown: {
    hard_skills: string[];
    soft_skills: string[];
    success_metrics: string[];
  };
}

export async function generateTailoredPackage(
  jd: string,
  baseCv: string,
  userNotes?: string,
  selections?: { resume: boolean; coverLetter: boolean; email: boolean }
): Promise<TailoredPackage> {
  const prompt = `
    Job Description:
    ${jd}
    
    Source Documents Required:
    ${selections?.resume ? "- Tailored Resume" : ""}
    ${selections?.coverLetter ? "- Cover Letter" : ""}
    ${selections?.email ? "- LOR Request Email" : ""}

    User's Data (Achievements and Awards / LaTeX or Markdown):
    ${baseCv}
    
    User's Additional Notes:
    ${userNotes || "None"}

    TASK:
    1. Analyze the JD for Hard Skills, Soft Skills, and Success Metrics.
    2. ${selections?.resume ? "ONLY if requested: Generate the 'tailored_resume' using this EXACT CHRONOLOGICAL TEMPLATE:" : "Skip resume generation."}
       ${selections?.resume ? `
       # [Full Name]
       [Email] | [Phone] | [Website Link] | [GitHub Link (Include only if present in input)]

       ## Summary
       [A powerful professional summary]

       ## Skills
       [Exactly 2-3 sentences summarizing core technical and professional competencies]

       ## Education
       [Qualification/Degree], [College/University Name], [Date Range]

       ## Experiences
       **[Job Title]** | [Company Name] | [Date Range]
       - [Achievement 1 with metrics]
       - [Achievement 2 focused on JD keywords]
       - [Achievement 3 specific impact]
       *(Note: EXACTLY 3 bullet points per experience element)*

       ## Projects
       **[Project Title]** | [Date]
       - [Bullet 1 describing tech stack and goal]
       - [Bullet 2 describing implementation]
       - [Bullet 3 describing result/impact]
       *(Note: EXACTLY 3 bullet points per project element)*
       ` : ""}
    3. Use EXCLUSIVELY facts from the 'Achievements and Awards' input. Do not hallucinate.
    4. Calculate a match score (0-100).
    5. ${selections?.coverLetter ? "ONLY if requested: Generate a Cover Letter following this template:" : "Skip cover letter."}
       ${selections?.coverLetter ? `
       ---
       Dear [Hiring Manager],
       [Hook linking shared mission]
       [Proof point linking user achievement to company problem X in JD]
       [Closing]
       ---` : ""}
    6. ${selections?.email ? "ONLY if requested: Generate a Letter of Recommendation (LOR) Request Email." : "Skip email generation."}

    Return the result as a detailed JSON object.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      systemInstruction: "You are the 'MakeResume' AI Engine. You transform raw career data (provided as Markdown, Plain Text, or LaTeX) into a high-conversion application package. Only use provided facts. No hallucinations. If input is in LaTeX, parse the content structure accurately.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        required: ["keyword_match_score", "analysis_breakdown"],
        properties: {
          tailored_resume: { type: Type.STRING, description: "The edited resume in Markdown format. Omit if not requested." },
          keyword_match_score: { type: Type.NUMBER, description: "Match score from 0 to 100." },
          cover_letter: { type: Type.STRING, description: "Tailored cover letter in Markdown format. Omit if not requested." },
          lor_request_email: { type: Type.STRING, description: "Tailored LOR request email. Omit if not requested." },
          analysis_breakdown: {
            type: Type.OBJECT,
            required: ["hard_skills", "soft_skills", "success_metrics"],
            properties: {
              hard_skills: { type: Type.ARRAY, items: { type: Type.STRING } },
              soft_skills: { type: Type.ARRAY, items: { type: Type.STRING } },
              success_metrics: { type: Type.ARRAY, items: { type: Type.STRING } },
            }
          }
        }
      }
    }
  });

  return JSON.parse(response.text || '{}');
}
