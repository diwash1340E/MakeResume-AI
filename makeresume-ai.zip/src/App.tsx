import React from "react";
import { Sidebar } from "./components/Sidebar";
import { PackageDisplay } from "./components/PackageDisplay";
import { generateTailoredPackage, TailoredPackage } from "./services/gemini";
import { motion, AnimatePresence } from "motion/react";

const INITIAL_BASE_CV = `# John Doe
**Software Engineer**
j.doe@email.com | 123-456-7890

## Experience
**Tech Solutions Inc.** | Senior Developer | 2021 - Present
- Led a team of 5 to migrate legacy monolithic architecture to microservices using Node.js and AWS.
- Reduced database query latency by 45% by implementing Redis caching.
- Optimized CI/CD pipelines, cutting deployment time from 1 hour to 12 minutes.

**WebCraft Agency** | Junior Developer | 2019 - 2021
- Developed 20+ responsive web applications using React and TypeScript.
- Collaborated with designers to ensure UI/UX consistency across all projects.

## Skills
- Languages: JavaScript, TypeScript, Python
- Frameworks: React, Node.js, Express, Next.js
- Tools: AWS, Docker, Jenkins, Git`;

const INITIAL_JD = `Position: Senior Backend Engineer
Company: CloudSync
Location: Remote

We are looking for a Senior Backend Engineer to join our growing team. You will be responsible for building scalable cloud-native applications.

Required Skills:
- 5+ years of experience with Node.js and TypeScript.
- Deep understanding of microservices architecture and cloud platforms (AWS preferred).
- Experience optimizing performance and scaling distributed systems.
- Strong collaboration skills and experience leading technical projects.

Success Metrics:
- Successful delivery of high-available services (99.9% uptime).
- Improvements in engineering productivity and system performance.`;

export type TabType = "resume" | "cover_letter" | "email";

export default function App() {
  const [baseCv, setBaseCv] = React.useState(INITIAL_BASE_CV);
  const [jd, setJd] = React.useState(INITIAL_JD);
  const [notes, setNotes] = React.useState("");
  const [result, setResult] = React.useState<TailoredPackage | null>(null);
  const [isLoading, setIsLoading] = React.useState(false);
  const [status, setStatus] = React.useState("Ready");
  const [activeTab, setActiveTab] = React.useState<TabType>("resume");
  const [selections, setSelections] = React.useState({
    resume: true,
    coverLetter: true,
    email: true
  });

  const handleSelectionChange = (type: keyof typeof selections) => {
    setSelections(prev => ({
      ...prev,
      [type]: !prev[type]
    }));
  };

  const handleGenerate = async () => {
    setIsLoading(true);
    setStatus("Analyzing Job Description");
    
    try {
      setTimeout(() => setStatus("Mapping your achievements"), 2000);
      setTimeout(() => setStatus("Generating tailored package"), 4000);
      
      const packageData = await generateTailoredPackage(jd, baseCv, notes, selections);
      setResult(packageData);
      setStatus("Complete");
    } catch (error) {
      console.error("Error generating package:", error);
      setStatus("Error generated");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-light-gray font-serif text-text-main antialiased overflow-hidden">
      <Sidebar
        score={result?.keyword_match_score || 0}
        onGenerate={handleGenerate}
        isLoading={isLoading}
        baseCv={baseCv}
        setBaseCv={setBaseCv}
        jd={jd}
        setJd={setJd}
        notes={notes}
        setNotes={setNotes}
        status={status}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selections={selections}
        onSelectionChange={handleSelectionChange}
      />

      <main className="relative flex-1 flex flex-col min-w-0 bg-white">
        <AnimatePresence mode="wait">
          {isLoading ? (
            <motion.div
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-white/80 backdrop-blur-sm z-20 flex flex-col items-center justify-center"
            >
              <div className="relative">
                <div className="w-20 h-20 border-4 border-slate-100 border-t-navy rounded-full animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-12 h-12 bg-navy/5 rounded-full animate-pulse" />
                </div>
              </div>
              <p className="mt-8 text-lg font-bold text-navy font-serif tracking-tight animate-pulse transition-all duration-500">
                {status}...
              </p>
              <p className="mt-2 text-sm text-slate font-serif">
                Our AI is matching your success to the job's needs.
              </p>
            </motion.div>
          ) : null}
        </AnimatePresence>

        <PackageDisplay data={result} activeTab={activeTab} />
      </main>
    </div>
  );
}
