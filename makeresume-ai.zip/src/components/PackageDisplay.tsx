import React from "react";
import ReactMarkdown from "react-markdown";
import { Briefcase, Download, Copy, Check, Award, Loader2 } from "lucide-react";
import { cn } from "@/src/lib/utils";
import { TailoredPackage } from "../services/gemini";
import { TabType } from "../App";
// @ts-ignore
import html2pdf from "html2pdf.js";

interface PackageDisplayProps {
  data: TailoredPackage | null;
  activeTab: TabType;
}

export function PackageDisplay({ data, activeTab }: PackageDisplayProps) {
  const [copied, setCopied] = React.useState(false);
  const [exporting, setExporting] = React.useState(false);
  const contentRef = React.useRef<HTMLDivElement>(null);

  if (!data) {
    return (
      <div className="flex-1 flex items-center justify-center bg-light-gray p-12">
        <div className="text-center max-w-sm p-8 bg-white rounded-2xl shadow-sm border border-border">
          <div className="w-16 h-16 bg-light-gray rounded-xl flex items-center justify-center mx-auto mb-6">
            <Briefcase className="w-8 h-8 text-slate/30" />
          </div>
          <h2 className="text-xl font-extrabold text-navy mb-3 font-serif">Professional Suite</h2>
          <p className="text-sm text-slate font-serif leading-relaxed">
            Generate your high-conversion package to see the results here in a tailored editor view.
          </p>
        </div>
      </div>
    );
  }

  const handleCopy = () => {
    const textToCopy = 
      activeTab === "resume" ? data.tailored_resume :
      activeTab === "cover_letter" ? data.cover_letter :
      data.lor_request_email;
    
    if (!textToCopy) return;
    
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportPdf = async () => {
    if (!contentRef.current || exporting) return;
    
    setExporting(true);
    try {
      const element = contentRef.current;
      const fileName = `${data.analysis_breakdown.hard_skills[0] || 'Document'}_${activeTab}.pdf`;
      
      const opt = {
        margin: 10,
        filename: fileName,
        image: { type: 'jpeg' as const, quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' as const }
      };

      await html2pdf().from(element).set(opt).save();
    } catch (error) {
      console.error("PDF Export failed:", error);
    } finally {
      setExporting(false);
    }
  };

  const currentContent = 
    activeTab === "resume" ? data.tailored_resume :
    activeTab === "cover_letter" ? data.cover_letter :
    data.lor_request_email;

  return (
    <div className="flex-1 flex flex-col h-screen bg-light-gray overflow-hidden">
      {/* Browser Mockup Header */}
      <div className="h-10 bg-border flex items-center px-4 gap-2 flex-shrink-0">
        <div className="flex gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-slate/20" />
          <div className="w-2.5 h-2.5 rounded-full bg-slate/20" />
          <div className="w-2.5 h-2.5 rounded-full bg-slate/20" />
        </div>
        <div className="flex-1 bg-white h-6 rounded flex items-center px-3 text-[10px] text-slate/60 font-medium">
          makeresume.ai/package/{activeTab}
        </div>
      </div>

      {/* Toolbar */}
      <div className="bg-white border-b border-border px-6 py-2 flex items-center justify-between shadow-sm z-10">
        <div className="flex items-center gap-4">
           <div className="flex items-center gap-1.5">
             <Award className="w-3.5 h-3.5 text-navy" />
             <span className="text-[9px] uppercase tracking-widest font-black text-slate/40">Analysis</span>
           </div>
           <div className="flex gap-1.5">
            {data.analysis_breakdown.hard_skills.slice(0, 3).map((skill, i) => (
              <span key={i} className="px-2 py-0.5 bg-neutral-100 text-neutral-900 text-[9px] font-bold rounded border border-neutral-200 tracking-tight">
                {skill}
              </span>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            disabled={!currentContent || exporting}
            className="p-1.5 px-3 rounded-md border border-border hover:bg-light-gray text-slate transition-all disabled:opacity-20 disabled:cursor-not-allowed flex items-center gap-1.5 text-[10px] font-bold"
          >
            {copied ? <Check className="w-3 h-3 text-success" /> : <Copy className="w-3 h-3" />}
            {copied ? "Copied" : "Copy"}
          </button>
          <button 
            onClick={handleExportPdf}
            disabled={!currentContent || exporting}
            className="flex items-center gap-1.5 bg-navy text-white px-4 py-1.5 rounded-md font-bold text-[10px] hover:shadow-sm transition-all disabled:opacity-20 disabled:cursor-not-allowed uppercase tracking-wider min-w-[70px] justify-center"
          >
            {exporting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Download className="w-3 h-3" />}
            {exporting ? "..." : "PDF"}
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-8 custom-scrollbar bg-light-gray">
        <div 
          ref={contentRef}
          className={cn(
            "w-full bg-white shadow-xl border border-border rounded-xl min-h-screen transition-all duration-300",
            "font-serif", // Explicitly use Times New Roman
            activeTab === "resume" ? "p-12" : "p-16", // Reduced padding
            "prose prose-sm max-w-none" // Removed prose-slate
          )}
        >
           {!currentContent && (
             <div className="flex flex-col items-center justify-center h-full min-h-[500px] text-center space-y-3 opacity-30">
                <div className="w-10 h-10 rounded-full border border-dashed border-slate flex items-center justify-center">
                  <div className="w-5 h-5 bg-slate/10 rounded-full" />
                </div>
                <p className="text-[10px] font-black uppercase tracking-widest">Document Unavailable</p>
                <p className="text-[9px] max-w-xs mx-auto">Please check the document in the sidebar and regenerate.</p>
             </div>
           )}
           <div className={cn(
             activeTab !== "resume" && "space-y-6 text-base leading-relaxed" // Reduced text size and spacing
           )}>
            <ReactMarkdown>
              {currentContent || ""}
            </ReactMarkdown>
           </div>
        </div>
      </div>
    </div>
  );
}
