import { FileText, Mail, Send, Award, ChefHat } from "lucide-react";
import { cn } from "@/src/lib/utils";
import { MatchScoreGauge } from "./MatchScoreGauge";
import { TabType } from "../App";

interface SidebarProps {
  score: number;
  onGenerate: () => void;
  isLoading: boolean;
  baseCv: string;
  setBaseCv: (cv: string) => void;
  jd: string;
  setJd: (jd: string) => void;
  notes: string;
  setNotes: (notes: string) => void;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  status: string;
  selections: {
    resume: boolean;
    coverLetter: boolean;
    email: boolean;
  };
  onSelectionChange: (type: keyof SidebarProps["selections"]) => void;
}

export function Sidebar({
  score,
  onGenerate,
  isLoading,
  baseCv,
  setBaseCv,
  jd,
  setJd,
  notes,
  setNotes,
  activeTab,
  setActiveTab,
  status,
  selections,
  onSelectionChange
}: SidebarProps) {
  const tabs = [
    { id: "resume", label: "Resume", icon: FileText, selected: selections.resume },
    { id: "cover_letter", label: "Cover Letter", icon: Mail, selected: selections.coverLetter },
    { id: "email", label: "Email", icon: Send, selected: selections.email },
  ] as const;

  return (
    <aside className="w-[340px] h-screen bg-white shadow-[-4px_0_15px_rgba(0,0,0,0.05)] flex flex-col z-10 flex-shrink-0">
      {/* Sidebar Header */}
      <div className="bg-navy text-white p-4 flex items-center gap-3">
        <div className="w-9 h-9 bg-white rounded-lg flex items-center justify-center text-navy shadow-md">
          <ChefHat className="w-5 h-5" />
        </div>
        <div>
          <div className="font-extrabold text-base leading-tight tracking-tight">MakeResume AI</div>
          <div className="text-[10px] opacity-70 italic mt-0.5">"Let's Cook the Job Market before it cooks you"</div>
        </div>
      </div>

      {/* Status Section */}
      <div className="p-3 border-b border-border text-center flex items-center justify-center gap-3">
        <MatchScoreGauge score={score} />
        <div className="text-left">
          <div className="text-[11px] font-bold text-slate uppercase tracking-wider opacity-60">
            Match
          </div>
          <div className="text-lg font-black text-navy leading-none">Score</div>
        </div>
      </div>

      {/* Action Section */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 custom-scrollbar bg-white">
        {/* Focused Input Area */}
        <div className="flex flex-col space-y-2 h-[50%]">
          <div className="flex items-center justify-between">
            <h3 className="text-[12px] font-black text-navy uppercase tracking-[0.05em]">
              Achievements and Awards
            </h3>
            <span className="text-[10px] font-bold text-white bg-navy px-1.5 py-0.5 rounded-xs uppercase tracking-wider">
              High Focus
            </span>
          </div>
          <textarea
            value={baseCv}
            onChange={(e) => setBaseCv(e.target.value)}
            placeholder="What are your wins? List achievements, metrics, and key skills..."
            className="w-full flex-1 p-3 text-sm border-2 border-slate-100 rounded-lg focus:ring-0 focus:border-navy resize-none bg-slate-50/20 font-serif transition-all placeholder:text-slate-300 leading-relaxed"
          />
        </div>

        {/* Supporting Context */}
        <div className="space-y-5">
          <div className="space-y-2">
            <label className="block text-[12px] font-bold text-slate uppercase tracking-wider">
              Target Job Context
            </label>
            <textarea
              value={jd}
              onChange={(e) => setJd(e.target.value)}
              placeholder="Paste job description here..."
              className="w-full h-20 p-3 text-sm border border-slate-100 rounded-lg focus:ring-0 focus:border-navy resize-none bg-slate-50/20 font-serif transition-all placeholder:text-slate-300"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-[12px] font-bold text-slate uppercase tracking-wider">
              Package Configuration
            </label>
            <div className="flex flex-wrap gap-1.5">
              {[
                { id: "resume", label: "Resume", key: "resume" },
                { id: "coverLetter", label: "Letter", key: "coverLetter" },
                { id: "email", label: "Email", key: "email" },
              ].map((item) => (
                <label 
                  key={item.id}
                  className={cn(
                    "flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-[11px] font-black uppercase tracking-tight transition-all cursor-pointer",
                    selections[item.key as keyof typeof selections]
                      ? "bg-navy text-white border-navy shadow-xs"
                      : "bg-white text-slate-400 border-slate-100 hover:border-slate-200"
                  )}
                >
                  <input 
                    type="checkbox" 
                    checked={selections[item.key as keyof typeof selections]} 
                    onChange={() => onSelectionChange(item.key as keyof typeof selections)}
                    className="hidden"
                  />
                  {item.label}
                </label>
              ))}
            </div>
          </div>

          <div className="space-y-2 pb-4">
            <label className="block text-[12px] font-bold text-slate uppercase tracking-wider">
              Optimization Notes
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Highlight cloud architecture..."
              className="w-full p-2.5 text-sm border border-slate-100 rounded-lg focus:ring-0 focus:border-navy bg-slate-50/20 font-serif transition-all placeholder:text-slate-300"
            />
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border mt-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "flex-1 py-2 text-center text-xs font-black uppercase tracking-wider transition-all border-b-2 leading-none",
              activeTab === tab.id
                ? "text-navy border-navy"
                : "text-slate/40 border-transparent hover:text-navy/60"
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Footer Actions */}
      <div className="p-4 bg-light-gray">
        <button
          onClick={onGenerate}
          disabled={isLoading || !baseCv || !jd}
          className={cn(
            "w-full py-3.5 bg-navy text-white border-none rounded-lg font-black text-sm uppercase tracking-widest cursor-pointer transition-all shadow-md active:scale-[0.98] disabled:shadow-none",
            (isLoading || !baseCv || !jd) ? "opacity-30 cursor-not-allowed" : "hover:bg-neutral-800"
          )}
        >
          {isLoading ? "Analyzing..." : "Tailor Package"}
        </button>
        {isLoading && (
          <div className="mt-2 text-[10px] text-center text-slate font-black uppercase tracking-tighter opacity-40">
            {status}...
          </div>
        )}
      </div>
    </aside>
  );
}
